/*------------------------------------------------
 * File: config.h
 * Description: Include file with definitions for 
 *              the config module.
--------------------------------------------------*/
// Prototypes - Entry Points
void configCodes(void);
void initCodes(void); 

