/*------------------------------------------------
 * File: switches.h
 * Description: Include file with definitions for 
 *              the Switches Module.
--------------------------------------------------*/

#include <mc9s12dg256.h>
// Protoypes - Prototypes
void initSwitches(void);
byte getSwStatus(void);

